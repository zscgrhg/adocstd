require "asciidoctor/pdf/cjk"
require "asciidoctor/pdf/cjk/kai_gen_gothic/version"
require "asciidoctor/pdf/cjk/kai_gen_gothic/theme_loader.rb"

module Asciidoctor
  module Pdf
    module CJK
      module KaiGenGothic
      end
    end
  end
end
