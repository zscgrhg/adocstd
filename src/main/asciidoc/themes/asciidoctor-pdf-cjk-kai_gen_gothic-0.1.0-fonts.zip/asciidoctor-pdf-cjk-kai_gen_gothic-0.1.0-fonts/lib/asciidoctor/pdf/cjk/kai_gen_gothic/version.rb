module Asciidoctor
  module Pdf
    module CJK
      module KaiGenGothic
        VERSION = "0.0.0"
      end
    end
  end
end
