$LOAD_PATH.unshift File.expand_path('../../lib', __FILE__)
require 'asciidoctor/pdf/cjk/kai_gen_gothic'

require 'minitest/autorun'
